from dash import Dash, html, dcc
import dash_bootstrap_components as dbc
import plotly.express as px
import geopandas as gpd
from pathlib import Path
import pandas as pd
from dash.dependencies import Input, Output
import json

# Set up data folder path and read data
dataset_folder = Path('Concatenated_AnnualInflation/')
inflation_gdf_geojson = gpd.read_file(dataset_folder / 'concatenated_annualinflation_df.geojson', driver='GeoJSON')
# Load the datasets
region1data = pd.read_csv(dataset_folder/'BarRegion I.csv')
region2data = pd.read_csv(dataset_folder/'BarRegion II.csv')
region3data = pd.read_csv(dataset_folder/'BarRegion III.csv')
region4data = pd.read_csv(dataset_folder/'BarRegion IV.csv')
region5data = pd.read_csv(dataset_folder/'BarRegion V.csv')
region6data = pd.read_csv(dataset_folder/'BarRegion VI.csv')
region7data = pd.read_csv(dataset_folder/'BarRegion VII.csv')
region8data = pd.read_csv(dataset_folder/'BarRegion VIII.csv')
region9data = pd.read_csv(dataset_folder/'BarRegion IX.csv')
region10data = pd.read_csv(dataset_folder/'BarRegion X.csv')
region11data = pd.read_csv(dataset_folder/'BarRegion XI.csv')
region12data = pd.read_csv(dataset_folder/'BarRegion XII.csv')
region13data = pd.read_csv(dataset_folder/'BarRegion XIII.csv')
regionNCRdata = pd.read_csv(dataset_folder/'BarNCR.csv')
regionCARdata = pd.read_csv(dataset_folder/'BarCAR.csv')
regionBARMMdata = pd.read_csv(dataset_folder/'BarBARMM.csv')
regionMIMAROPAdata = pd.read_csv(dataset_folder/'BarMIMAROPA.csv')
regionMAINdata = pd.read_csv(dataset_folder/'BarPhilippines.csv')
regionLINEdata = pd.read_csv(dataset_folder/'LineChartDataset.csv')
treemapdata = pd.read_excel(dataset_folder / 'Inflation (Regional % Contribution).xlsx', sheet_name = "COMPILED Regional")

px.set_mapbox_access_token(open(".mapbox_token").read())
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])


#Set up the choropleth map figure
inflation_gdf_indexed = inflation_gdf_geojson.set_index('Province')
fig = px.choropleth(
    inflation_gdf_indexed,
    geojson=inflation_gdf_indexed.geometry,
    locations=inflation_gdf_indexed.index,
    color='Annual Inflation Rate',
    color_continuous_scale="Viridis",  # Use a professional color 
    center={'lat': 12.099568, 'lon': 122.733168},
    title='Philippine Map According to Annual Regional Inflation Rates',
        )       # Adjust the font color of the instruction

fig.add_annotation(
    text="Hover over the map to view provincial details, click a region to proceed.",  # Instruction text
    x=0.5,
    y=-0.1,  # Adjust the vertical position of the instruction below the title
    xanchor="center",  # Anchor point for x coordinate
    yanchor="bottom",  # Anchor point for y coordinate
    font=dict(size=13, color="gray"),  # Font properties for the instruction text
    showarrow=False,  # Hide the arrow pointing to the annotation
)

fig.update_geos(fitbounds="locations", visible=False, bgcolor="#C9D1D2")
fig.update_layout(coloraxis_colorbar=dict(title="Annual Inflation Rate"), 
                  paper_bgcolor="white",
                geo=dict(
                    visible=False,  # Hide the default background map
                    bgcolor='rgba(255, 255, 255, 0)',
                    showframe=True,
                    framecolor='black',
                    framewidth=2  # Set background color to transparent
                    ),
                )

# Set up the Treemap figure
maptree = px.treemap(
    names = treemapdata.Labels,
    parents = treemapdata.Parents,
    values = treemapdata["Overall"],
    branchvalues="total",
    color_discrete_sequence=px.colors.qualitative.Dark24,
    color = treemapdata.color,
    title='Overall Philippine Percent Contribution to Inflation by Commodity Group'
)
maptree.update_traces(root_color="lightgrey")
maptree.update_layout(margin = dict(t=50, l=25, r=25, b=25))

# Bar and Line Chart
# # This one is for selecting the region to show on the line chart
# selected_line = regionLINEdata['Region']
# # This one is to filter the dataframe to the selected region
# filtered_line = regionLINEdata[regionLINEdata['Region'].isin(selected_line)]
# # This one is to create the line chart
# linechart = px.line(filtered_line, x='Month', y='Inflation', markers=True, title='Regional Inflation Rates by Region', hover_data={'Region': True})
# #linechart.show()

#Revised Bar and Line Chart - Including Overall PH
selected_line = regionLINEdata['Region']
# This one is to filter the dataframe to the selected region
filtered_line = regionLINEdata[regionLINEdata['Region'] == 'Philippines']
# This one is to create the line chart
linechart = px.line(filtered_line, x='Month', y='Inflation', markers=True, title='National Inflation Rate of the Philippines (Monthly)', hover_data={'Region': True})
#linechart.show()


# This one is for selecting the commodities to show on the bar chart
selected_bar = ['01 - FOOD AND NON-ALCOHOLIC BEVERAGES', '07 - TRANSPORT', '04 - HOUSING, WATER, ELECTRICITY, GAS, AND OTHER FUELS']
# This one is to filter the dataframe to the selected commodities
filtered_bar = region1data[region1data['Commodity Group'].isin(selected_bar)]
# This one is to create the bar chart
barchart = px.bar(filtered_bar, x='Month', y='Inflation', color='Commodity Group',
             barmode='group', title='Philippine Inflation Rates by Commodity Group (Monthly)')
barchart.update_layout(
    xaxis=dict(
        title='Month',  # Add x-axis title
        tickfont=dict(size=12)  # Adjust the font size of x-axis labels
    ),
    yaxis=dict(
        title='Inflation Rate',  # Add y-axis title
        tickfont=dict(size=6)  # Adjust the font size of y-axis labels
    ),
    font=dict(
        size=14,  # Adjust the font size of text within the chart (title, legend, etc.)
        family="Arial"  # Adjust the font family of text within the chart
    )
)
#barchart.update_layout(xaxis_title='Month', yaxis_title='Inflation Rate')

# Initialize the Dash application
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Define the navbar and layout of the app
navbar = dbc.NavbarSimple(
    children=[dbc.NavItem(dbc.NavLink("Home", href="#"))],
    brand="Philippine Regional Inflation Dashboard",
    brand_href="#",
    color="success",
    dark=True,
    className="mb-2",  # Add margin bottom for spacing
)
# 1.5 Events

fig.update_layout(clickmode='event+select')

styles = {
    'pre': {
        'border': 'thin lightgrey solid',
        'overflowX': 'scroll'
    }
}

# Define the layout with actual choropleth map and placeholders for other charts
app.layout = dbc.Container([
    dbc.NavbarSimple(
        children=[dbc.NavItem(dbc.NavLink("Home", href="#"))],
        brand="Philippine Inflation Dashboard",
        brand_href="#",
        color="green",
        dark=True,
        className="mb-5",  # Increased margin-bottom for more space
    ),
    dbc.Row([
        dbc.Col(html.H1("Philippine Regional Inflation Dashboard (2023)",
                        className="text-center mb-4"), width=12),
        dbc.Col(html.H6("(Source: Philippine Statistics Authority)",
                        className="text-center mb-5"), width=12),
    ]),
    dbc.Row([
        dbc.Col(dcc.Graph(id='choropleth-map', figure=fig), width=12, lg=6),
        dbc.Col(dcc.Graph(id='linechart', figure=linechart), width=12, lg=6),
    ]),
    dbc.Row([
        dbc.Col(dcc.Graph(id='barchart', figure=barchart), width=12, lg=6),
        dbc.Col(dcc.Graph(id='treemap', figure=maptree), width=12, lg=6),  # Reduced size for the treemap
    ]),
    dbc.Row([
        dbc.Col(html.Div("For detailed analysis and more information, please refer to the official PSA publications.",
                         className="text-center my-4")),  # Adjusted margin top and bottom
    ]),
], fluid=True, style={'backgroundColor': '#f8f9fa'})  # Adjusted background color for the container


#Callbacks

# Assuming inflation_gdf_geojson has a 'Province' column with a matching 'Region' column.
province_to_region_mapping = inflation_gdf_geojson.set_index('Province')['Region'].to_dict()

# Assuming you have a function that returns the correct DataFrame based on a given region
def get_region_data(clicked_region):
    region_to_data = {
        'Region I': region1data,
        'Region II': region2data,
        'Region III': region3data,
        'Region IV': region4data,
        'Region V': region5data,
        'Region VI': region6data,
        'Region VII': region7data,
        'Region VIII': region8data,
        'Region IX': region9data,
        'Region X': region10data,
        'Region XI': region11data,
        'Region XII': region12data,
        'Region XIII': region13data,
        'NCR': regionNCRdata,
        'CAR': regionCARdata,
        'BARMM': regionBARMMdata,
        'MIMAROPA': regionMIMAROPAdata,
        # Add any additional regions if necessary
    }
    return region_to_data.get(clicked_region, pd.DataFrame())  # Returns an empty DataFrame if the region is not found


@app.callback(
    [Output('linechart', 'figure'), Output('barchart', 'figure'), Output('treemap','figure')],
    [Input('choropleth-map', 'clickData')]
)
def update_charts(clickData):
    # Return the default figures if no data is clicked
    if clickData is None:
        return linechart, barchart, maptree
    
    # Get the clicked province and the corresponding region
    clicked_province = clickData['points'][0]['location']
    clicked_region = province_to_region_mapping.get(clicked_province)
    
    # Return the default figures if the province isn't found in the mapping
    if not clicked_region:
        return linechart, barchart, maptree
    
    # Update the line chart with the data from the corresponding region
    filtered_linechart_data = regionLINEdata[regionLINEdata['Region'] == clicked_region]
    updated_linechart = px.line(
        filtered_linechart_data,
        x='Month', y='Inflation', 
        title=f'Regional Inflation Rates for {clicked_region}', 
        markers=True
    )
    
    filteredmaptree = px.treemap(
    names = treemapdata.Labels,
    parents = treemapdata.Parents,
    values = treemapdata[clicked_region],
    branchvalues="total",
    color_discrete_sequence=px.colors.qualitative.Dark24,
    color = treemapdata.color,
    )
    filteredmaptree.update_traces(root_color="lightgrey")
    filteredmaptree.update_layout(margin = dict(t=50, l=25, r=25, b=25),
                                  title=f'Commmodity Group Percent Contribution to Inflation for {clicked_region}')

    # Get the correct DataFrame for the clicked region for the bar chart
    region_bar_data = get_region_data(clicked_region)
    
    # Check if 'Commodity Group' column exists in the DataFrame
    if 'Commodity Group' not in region_bar_data.columns:
        # Return the default figures if 'Commodity Group' column does not exist
        return updated_linechart, barchart, filteredmaptree
    
    # Filter the data for the bar chart
    filtered_barchart_data = region_bar_data[region_bar_data['Commodity Group'].isin(selected_bar)]
    updated_barchart = px.bar(
        filtered_barchart_data,
        x='Month', y='Inflation', 
        color='Commodity Group', 
        barmode='group',
        title=f'Inflation Rates by Commodity Group for {clicked_region}'
    )
    #updated_barchart.update_layout(xaxis_title='Month', yaxis_title='Inflation Rate')
    updated_barchart.update_layout(
    legend=dict(
        font=dict(size=12),
          orientation='v'  # Adjust the size of the legend font
    )
)
    updated_barchart.update_layout(
    xaxis_title='Month', 
    yaxis_title='Inflation Rate',
)
    # Return the updated figures
    return updated_linechart, updated_barchart, filteredmaptree


# Run the Dash app
if __name__ == '__main__':
    app.run_server(debug=True)
